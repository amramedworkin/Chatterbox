"use strict";
// src/aws/emailProcessor.ts
// AWS-native email processing system
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.processEmail = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
const client_s3_1 = require("@aws-sdk/client-s3");
const client_sqs_1 = require("@aws-sdk/client-sqs");
const client_secrets_manager_1 = require("@aws-sdk/client-secrets-manager");
const client_ssm_1 = require("@aws-sdk/client-ssm");
const uuid_1 = require("uuid");
// AWS Clients
const dynamoClient = new client_dynamodb_1.DynamoDBClient({});
const docClient = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient);
const s3Client = new client_s3_1.S3Client({});
const sqsClient = new client_sqs_1.SQSClient({});
const secretsClient = new client_secrets_manager_1.SecretsManagerClient({});
const ssmClient = new client_ssm_1.SSMClient({});
// Configuration
const CONFIG = {
    TABLES: {
        EMAIL_QUERIES: 'chatterbox-email-queries',
        CONVERSATIONS: 'chatterbox-conversations',
        USER_PROFILES: 'chatterbox-user-profiles',
        QUERY_RECORDS: 'chatterbox-query-records',
    },
    BUCKETS: {
        ATTACHMENTS: 'chatterbox-attachments',
    },
    QUEUES: {
        RESPONSE_GENERATION: 'chatterbox-response-generation',
    },
    PARAMETERS: {
        REJECTION_RATE_LIMIT: '/chatterbox/email/rejection-rate-limit',
        DEFAULT_MODEL: '/chatterbox/llm/default-model',
        FREE_TIER_LIMIT: '/chatterbox/billing/free-tier-limit',
    },
};
/**
 * Parse email directives (conversation ID, model name)
 */
function parseEmailDirectives(subject, body) {
    let conversationId;
    let modelName;
    // Extract conversation ID (<<<guid>>> format)
    const conversationIdRegex = /<<<([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})>>>/g;
    const conversationMatches = [
        ...subject.matchAll(conversationIdRegex),
        ...body.matchAll(conversationIdRegex),
    ];
    if (conversationMatches.length > 0) {
        conversationId = conversationMatches[0][1];
    }
    // Extract model name (<<<model_name>>> format)
    const modelNameRegex = /<<<([^>]+)>>>/g;
    const modelMatches = [...subject.matchAll(modelNameRegex), ...body.matchAll(modelNameRegex)];
    for (const match of modelMatches) {
        const potentialModel = match[1];
        // Skip if it's a GUID (conversation ID)
        if (!/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/i.test(potentialModel)) {
            modelName = potentialModel;
            break;
        }
    }
    // Clean subject and body by removing directives
    let cleanSubject = subject.replace(conversationIdRegex, '').replace(modelNameRegex, '').trim();
    const cleanBody = body.replace(conversationIdRegex, '').replace(modelNameRegex, '').trim();
    // Remove "chatterbox" from subject if it's the first word
    cleanSubject = cleanSubject.replace(/^chatterbox\s+/i, '').trim();
    return {
        conversationId,
        modelName,
        cleanSubject,
        cleanBody,
    };
}
/**
 * Validate email query according to project specification
 */
function validateEmailQuery(subject, body) {
    // Check if "chatterbox" is in subject line
    if (!subject.toLowerCase().includes('chatterbox')) {
        return { isValid: false, reason: 'Subject line must contain "chatterbox"' };
    }
    // Check if query has content
    const cleanBody = body.trim();
    const cleanSubject = subject.replace(/^chatterbox\s+/i, '').trim();
    if (!cleanBody && !cleanSubject) {
        return { isValid: false, reason: 'Query must have content in body or subject' };
    }
    return { isValid: true };
}
/**
 * Upload attachment to S3
 */
async function uploadAttachmentToS3(attachment, queryId) {
    if (!attachment.data) {
        throw new Error('Attachment data is required for S3 upload');
    }
    const s3Key = `attachments/${queryId}/${attachment.filename}`;
    await s3Client.send(new client_s3_1.PutObjectCommand({
        Bucket: CONFIG.BUCKETS.ATTACHMENTS,
        Key: s3Key,
        Body: attachment.data,
        ContentType: attachment.mimeType,
        Metadata: {
            originalFilename: attachment.filename,
            size: attachment.size.toString(),
            queryId: queryId,
        },
    }));
    return s3Key;
}
/**
 * Get or create user profile
 */
async function getUserProfile(userEmail) {
    try {
        const result = await docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: CONFIG.TABLES.USER_PROFILES,
            Key: { userEmail },
        }));
        if (result.Item) {
            return result.Item;
        }
    }
    catch (error) {
        console.error('Error getting user profile:', error);
    }
    // Create default profile for new user
    const defaultProfile = {
        userEmail,
        subscriptionType: 'pay-per-use',
        preferredModel: await getDefaultModel(),
        persistenceEnabled: false,
        budgetLimits: {
            maxPerQuery: 10.0,
            maxDaily: 50.0,
            maxWeekly: 200.0,
            maxMonthly: 500.0,
            maxAnnual: 5000.0,
        },
        credits: 0,
        createdAt: new Date().toISOString(),
        lastUpdated: new Date().toISOString(),
    };
    await docClient.send(new lib_dynamodb_1.PutCommand({
        TableName: CONFIG.TABLES.USER_PROFILES,
        Item: defaultProfile,
    }));
    return defaultProfile;
}
/**
 * Get default model from Parameter Store
 */
async function getDefaultModel() {
    try {
        const result = await ssmClient.send(new client_ssm_1.GetParameterCommand({
            Name: CONFIG.PARAMETERS.DEFAULT_MODEL,
        }));
        return result.Parameter?.Value || 'gpt-4o';
    }
    catch (error) {
        console.error('Error getting default model:', error);
        return 'gpt-4o';
    }
}
/**
 * Check if user has exceeded free tier limit
 */
async function checkFreeTierLimit(userEmail) {
    try {
        const freeTierLimit = await ssmClient.send(new client_ssm_1.GetParameterCommand({
            Name: CONFIG.PARAMETERS.FREE_TIER_LIMIT,
        }));
        const limit = parseInt(freeTierLimit.Parameter?.Value || '10');
        // Count queries for this user
        const result = await docClient.send(new lib_dynamodb_1.QueryCommand({
            TableName: CONFIG.TABLES.QUERY_RECORDS,
            KeyConditionExpression: 'userEmail = :userEmail',
            ExpressionAttributeValues: {
                ':userEmail': userEmail,
            },
            Select: 'COUNT',
        }));
        const queryCount = result.Count || 0;
        if (queryCount >= limit) {
            return {
                allowed: false,
                reason: `Free tier limit of ${limit} queries exceeded. Please register for a paid account.`,
            };
        }
        return { allowed: true };
    }
    catch (error) {
        console.error('Error checking free tier limit:', error);
        return { allowed: true }; // Allow if check fails
    }
}
/**
 * Get conversation context if it exists
 */
async function getConversation(conversationId) {
    try {
        const result = await docClient.send(new lib_dynamodb_1.GetCommand({
            TableName: CONFIG.TABLES.CONVERSATIONS,
            Key: { conversationId },
        }));
        return result.Item || null;
    }
    catch (error) {
        console.error('Error getting conversation:', error);
        return null;
    }
}
/**
 * Create new conversation
 */
async function createConversation(conversationId, userEmail, modelName) {
    const conversation = {
        conversationId,
        userEmail,
        modelName,
        messages: [],
        lastUpdated: new Date().toISOString(),
        createdAt: new Date().toISOString(),
        totalCost: 0,
        totalTokens: 0,
    };
    await docClient.send(new lib_dynamodb_1.PutCommand({
        TableName: CONFIG.TABLES.CONVERSATIONS,
        Item: conversation,
    }));
    return conversation;
}
/**
 * Add message to conversation
 */
async function addMessageToConversation(conversationId, message) {
    await docClient.send(new lib_dynamodb_1.UpdateCommand({
        TableName: CONFIG.TABLES.CONVERSATIONS,
        Key: { conversationId },
        UpdateExpression: 'SET messages = list_append(messages, :message), lastUpdated = :lastUpdated',
        ExpressionAttributeValues: {
            ':message': [message],
            ':lastUpdated': new Date().toISOString(),
        },
    }));
}
/**
 * Store email query in DynamoDB
 */
async function storeEmailQuery(query) {
    await docClient.send(new lib_dynamodb_1.PutCommand({
        TableName: CONFIG.TABLES.EMAIL_QUERIES,
        Item: query,
    }));
}
/**
 * Send message to response generation queue
 */
async function queueResponseGeneration(queryId) {
    await sqsClient.send(new client_sqs_1.SendMessageCommand({
        QueueUrl: CONFIG.QUEUES.RESPONSE_GENERATION,
        MessageBody: JSON.stringify({ queryId }),
        MessageAttributes: {
            QueryType: {
                StringValue: 'email',
                DataType: 'String',
            },
        },
    }));
}
/**
 * Main email processing function
 */
async function processEmail(gmailId, userEmail, fromSender, subject, body, attachments, receivedDate) {
    try {
        console.log(`Processing email ${gmailId} from ${fromSender}`);
        // Validate email query
        const validation = validateEmailQuery(subject, body);
        if (!validation.isValid) {
            console.log(`Email validation failed: ${validation.reason}`);
            return { success: false, error: validation.reason };
        }
        // Parse email directives
        const { conversationId, modelName, cleanSubject, cleanBody } = parseEmailDirectives(subject, body);
        // Get user profile
        const userProfile = await getUserProfile(fromSender);
        // Check free tier limit for non-registered users
        if (userProfile.subscriptionType === 'pay-per-use' && userProfile.credits === 0) {
            const freeTierCheck = await checkFreeTierLimit(fromSender);
            if (!freeTierCheck.allowed) {
                return { success: false, error: freeTierCheck.reason };
            }
        }
        // Determine query type
        const queryType = conversationId ? 'conversation' : 'standalone';
        // Handle conversation context
        let conversation = null;
        if (conversationId) {
            conversation = await getConversation(conversationId);
            if (!conversation && userProfile.persistenceEnabled) {
                // Create new conversation if persistence is enabled
                conversation = await createConversation(conversationId, fromSender, modelName || userProfile.preferredModel);
            }
        }
        // Upload attachments to S3
        const processedAttachments = [];
        for (const attachment of attachments) {
            if (attachment.data) {
                const s3Key = await uploadAttachmentToS3(attachment, gmailId);
                processedAttachments.push({
                    ...attachment,
                    s3Key,
                    data: undefined, // Remove data from memory
                });
            }
        }
        // Create email query record
        const queryId = (0, uuid_1.v4)();
        const emailQuery = {
            queryId,
            gmailId,
            userEmail,
            fromSender,
            subject: cleanSubject,
            body: cleanBody,
            attachments: processedAttachments,
            conversationId,
            modelName: modelName || userProfile.preferredModel,
            receivedDate,
            queryType,
            status: 'pending',
            createdAt: new Date().toISOString(),
        };
        // Store query in DynamoDB
        await storeEmailQuery(emailQuery);
        // Add user message to conversation if applicable
        if (conversation && userProfile.persistenceEnabled && conversationId) {
            const userMessage = {
                messageId: (0, uuid_1.v4)(),
                role: 'user',
                content: cleanBody || cleanSubject,
                timestamp: new Date().toISOString(),
                gmailId,
            };
            await addMessageToConversation(conversationId, userMessage);
        }
        // Queue for response generation
        await queueResponseGeneration(queryId);
        console.log(`Successfully processed email ${gmailId}, queryId: ${queryId}`);
        return { success: true, queryId };
    }
    catch (error) {
        console.error('Error processing email:', error);
        return {
            success: false,
            error: error instanceof Error ? error.message : 'Unknown error',
        };
    }
}
exports.processEmail = processEmail;
/**
 * Lambda handler for email processing
 */
async function handler(event) {
    try {
        console.log('Email processing event:', JSON.stringify(event, null, 2));
        // Process S3 event (email content uploaded by pollGmail)
        if (event.Records && event.Records[0].eventSource === 'aws:s3') {
            const s3Record = event.Records[0].s3;
            const bucket = s3Record.bucket.name;
            const key = decodeURIComponent(s3Record.object.key);
            // Extract email metadata from S3 key
            // Expected format: emails/{gmailId}/metadata.json
            const keyParts = key.split('/');
            if (keyParts.length >= 3 && keyParts[0] === 'emails') {
                const gmailId = keyParts[1];
                // Get email metadata from S3
                const metadataResult = await s3Client.send(new client_s3_1.GetObjectCommand({
                    Bucket: bucket,
                    Key: key,
                }));
                const metadata = JSON.parse(await metadataResult.Body.transformToString());
                // Process the email
                const result = await processEmail(gmailId, metadata.userEmail, metadata.fromSender, metadata.subject, metadata.body, metadata.attachments || [], metadata.receivedDate);
                return {
                    statusCode: 200,
                    body: JSON.stringify(result),
                };
            }
        }
        return {
            statusCode: 400,
            body: JSON.stringify({ error: 'Invalid event format' }),
        };
    }
    catch (error) {
        console.error('Lambda handler error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                error: error instanceof Error ? error.message : 'Unknown error',
            }),
        };
    }
}
exports.handler = handler;
